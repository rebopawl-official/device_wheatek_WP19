TEE overlay for WP19 (Microtrust/ISEE). Структура = шлях усередині ramdisk.
Кладіть цю папку (tee-overlay) у корінь репозиторію з workflow.
v2: додано VINTF-фрагменти vendor/etc/vintf/manifest/*.xml для keymaster@4.1 та gatekeeper@1.0
    (hwservicemanager рано кешує device-маніфест, де були лише health; без цих HAL реєстрація може відхилятись).
