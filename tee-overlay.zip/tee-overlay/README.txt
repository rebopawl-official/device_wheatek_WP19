TEE overlay for WP19 (Microtrust/ISEE). Структура = шлях усередині ramdisk.
Кладіть tee-overlay.zip (або папку tee-overlay) у корінь репозиторію з workflow або device tree.
v2: VINTF-фрагменти vendor/etc/vintf/manifest/*.xml для keymaster@4.1 та gatekeeper@1.0
    (hwservicemanager рано кешує device-маніфест; без цих HAL реєстрація може відхилятись).
v3: teei_start.sh веде лог (/tmp/teei_start.log) і повторює монтування /vendor;
    vendor_keep.sh повторно монтує /vendor (recovery його відмонтовує на старті).
